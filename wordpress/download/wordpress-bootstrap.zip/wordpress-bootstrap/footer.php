<footer>
  <div class="container">
      2013 &copy; 
    <a href="http://fi-ware.eu/">
      FI-WARE.
    </a>
      The use of FI-LAB services is subject to the acceptance of the
    <a href="http://forge.fi-ware.eu/plugins/mediawiki/wiki/fiware/index.php/FI-LAB_Terms_and_Conditions">
      Terms and Conditions
    </a> 
      and 
    <a href="http://forge.fi-ware.eu/plugins/mediawiki/wiki/fiware/index.php/FI-LAB_Personal_Data_Protection_Policy">
      Personal Data Protection Policy
    </a>
  </div>
</footer>

<!-- end footer -->
    
        
    <!--[if lt IE 7 ]>
        <script src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.3/CFInstall.min.js"></script>
        <script>window.attachEvent('onload',function(){CFInstall.check({mode:'overlay'})})</script>
    <![endif]-->
    
    <?php wp_footer(); // js scripts are inserted using this function ?>

  </body>

</html>